# devops-docs

Учебный репозиторий практической работы № 9: Pylint, MkDocs, GitHub Actions и GitHub Pages.

- исходники документации: `docs/`;
- конфигурация MkDocs: `mkdocs.yml`;
- CI: `.github/workflows/quality.yml`;
- публикация: `.github/workflows/pages.yml`.

Каталог `site/` является результатом сборки и не хранится в Git.

Проект размещён в `practice9/`; workflow находятся в корневом `.github/workflows/`.
Сборка использует только учебный каталог `practice9/docs/`.
